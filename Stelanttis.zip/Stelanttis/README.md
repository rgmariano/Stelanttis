# Stellantis Global Solution

The proposal for the Global Solution comes in partnership with the Stellantis Group. Stellantis Group is one of the main corporations in the global automotive sector, having distinguished itself in the leadership of the main South American markets.

Faced with the various challenges related to mobility, such as education, health, housing, work and leisure, the Stellantis group, a partner of FIAP, seeks solutions for a new sustainable reality.

Meeting the sustainability tripod known as the triple bottom line involves attention to financial, environmental and social aspects, that is, to be sustainable, the company must pay attention to meeting the three aspects, having profits without harming the environment and collaborating for the social development of humanity.
