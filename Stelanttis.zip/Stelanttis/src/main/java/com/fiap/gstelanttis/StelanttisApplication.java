package com.fiap.gstelanttis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StelanttisApplication {

    public static void main(String[] args) {
        SpringApplication.run(StelanttisApplication.class, args);
    }

}
