package com.fiap.gstelanttis.service;


import com.fiap.gstelanttis.models.Regional;
import com.fiap.gstelanttis.models.Veiculo;
import com.fiap.gstelanttis.respositories.RegionalRepository;
import com.fiap.gstelanttis.respositories.VeiculoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@org.springframework.stereotype.Service
public class Service {

    @Autowired
    public VeiculoRepository veiculoRepository;
    @Autowired
    public RegionalRepository regionalRepository;

    public ResponseEntity salvar(Veiculo veiculo){
        try {
            Regional regional = new Regional();
            regional.setData(LocalDate.now());
            List<Veiculo> veiculos = new ArrayList<>();
            veiculos.add(veiculoRepository.save(veiculo));
            regional.setVeiculos(veiculos);
            regionalRepository.save(regional);
            return ResponseEntity.ok(regional);
        }catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }
}
