package com.fiap.gstelanttis.controller;

import com.fiap.gstelanttis.models.Veiculo;
import com.fiap.gstelanttis.respositories.RegionalRepository;
import com.fiap.gstelanttis.respositories.VeiculoRepository;
import com.fiap.gstelanttis.service.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "stellantis/")
@CrossOrigin(allowedHeaders = "*")
public class Controller {

    @Autowired
    private Service service;

    @Autowired
    private RegionalRepository regionalRepository;

    @Autowired
    private VeiculoRepository veiculoRepository;

    @GetMapping(path = "/")
    public ResponseEntity getAllVeiculos(){
        return ResponseEntity.ok(veiculoRepository.findAll());
    }

    @GetMapping(path = "/{id}")
    public ResponseEntity getVeiculoById(@PathVariable Long id){
        return veiculoRepository.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping(path = "/")
    public ResponseEntity postVeiculo(@RequestBody Veiculo veiculo){
        return ResponseEntity.status(HttpStatus.CREATED).body(service.salvar(veiculo));
    }
    @PutMapping(path = "/{id}")
    public ResponseEntity updateVeiculo(@RequestBody Veiculo veiculo){
        return ResponseEntity.status(HttpStatus.OK).body(veiculoRepository.save(veiculo));
    }

    @DeleteMapping(path = "/{id}")
    public ResponseEntity deleteVeiculo(@PathVariable long id){
        veiculoRepository.deleteById(id);
        return ResponseEntity.status(200).build();
    }

    @GetMapping(path = "/regional")
    public ResponseEntity getAllRegionais(){
        return ResponseEntity.ok(regionalRepository.findAll());
    }
}
