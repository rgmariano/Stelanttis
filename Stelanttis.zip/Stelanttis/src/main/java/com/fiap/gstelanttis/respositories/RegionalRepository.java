package com.fiap.gstelanttis.respositories;

import com.fiap.gstelanttis.models.Regional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RegionalRepository extends JpaRepository<Regional, Long> {
}