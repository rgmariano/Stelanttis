package com.fiap.gstelanttis.respositories;

import com.fiap.gstelanttis.models.Ambiente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AmbienteRepository extends JpaRepository<Ambiente, Long> {
}